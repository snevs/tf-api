exports.lambda_handler = async (event, context) => {
    console.log("Hello World");
    return "{'message': 'Hello World'}";
};
